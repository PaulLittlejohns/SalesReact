﻿class StoreLayout extends React.Component {
    constructor(props) {
        super(props);
        this.state = { show: false }
    }

    render() {
        return (
            <div>
                <StoreHead />
                <TableReact />
            </div>
        );
    }
}

// Modal
class Modal extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            idval: this.props.store.Id,
            nameval: this.props.store.StoreName,
            addressval: this.props.store.StoreAddress,
            showName: false,
            showAddress: false,
            saveBtn: '',
            headingMsg: ''
        }
        this.onHandleName = this.onHandleName.bind(this);
        this.onHandleAddress = this.onHandleAddress.bind(this);
        this.handleSave = this.handleSave.bind(this);
    }

    componentDidMount() {
        if (this.props.store.Id === '0') {
            this.setupCreateLabels()
        } else {
            this.setupEditLabels()
        }
    }

    componentWillReceiveProps(prevProps, prevState) {
        if (typeof prevProps.store.Id != "undefined") {
            if (prevProps.store.Id === "0") {
                this.setupCreateLabels()
            } else {
                this.setupEditLabels()
            }
            this.state.nameval = prevProps.store.StoreName
            this.state.addressval = prevProps.store.StoreAddress
        }
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.store.Id != prevState.idval) {
            this.setState({ idval: this.props.store.Id, nameval: this.props.store.StoreName, addressval: this.props.store.StoreAddress })
            if (prevProps.store.Id == '0') {
                this.setupCreateLabels()
            } else if (typeof prevProps.store.Id != 'undefined') {
                this.setupEditLabels()
            }
        }
    }

    setupCreateLabels() {
        this.setState({ showName: false, showAddress: false, saveBtn: 'Create', headingMsg: 'Create Record' })
    };

    setupEditLabels() {
        this.setState({ showName: true, showAddress: true, saveBtn: 'Save', headingMsg: 'Edit Record' })
    };

    onHandleName(e) {
        this.setState({ nameval: e.target.value })
        if (e.target.value.length === 0) {
            this.setState({ showName: false })
        } else {
            this.setState({ showName: true })
        }
    }

    onHandleAddress(e) {
        this.setState({ addressval: e.target.value })
        if (e.target.value.length === 0) {
            this.setState({ showAddress: false })
        } else {
            this.setState({ showAddress: true })
        }
    }

    disableButton() {
        if (this.state.showName == false || this.state.showAddress == false) {
            return true
        } else {
            return false
        }
    }

    handleSave() {
        var id = this.state.idval;
        var name = this.state.nameval;
        var address = this.state.addressval;
        $.ajax({
            url: 'Store/Save',
            data: {
                Id: id,
                StoreName: name,
                StoreAddress: address
            },
            type: 'POST',
            datatype: 'json'
        })
            .success(function (result) {
                alert(result.Message);
                location.reload();
            })
            .error(function () {
                alert("Unable to save changes. Contact the administrator.");
                location.reload;
            })
    }

    render() {
        const showHideClassName = this.props.show ? "modal display-block" : "modal display-none"
        return (
            <div className={showHideClassName}>
                <div className="modal-fade">
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-header">
                                <button type="button"
                                    className="close"
                                    onClick={handleClose}>&times;
                                 </button>
                                <h4 className="modal-title float-left">{this.state.headingMsg}</h4>
                            </div>
                            <div></div>
                            <div className="modal-body">
                                <div className="form-horizontal">
                                    <button type="button" className="btn btn-success" disabled={this.disableButton()} onClick={this.handleSave}>{this.state.saveBtn}</button>
                                    <div id="storeid" name="storeid" hidden="hidden">{this.state.idval}</div>
                                    <p>&nbsp;</p>
                                    <div>
                                        <h3 style={AllFieldsMsg}>All fields must have a value</h3>
                                    </div>
                                    <p>&nbsp;</p>
                                    <div>
                                        <label>Name: &nbsp;</label>
                                        <input type="text"
                                            id="storename"
                                            name="storename"
                                            style={FieldSize}
                                            onChange={this.onHandleName}
                                            value={this.state.nameval}>
                                        </input>
                                        <span id="storemsg" style={AllFieldsMsg} className={this.state.showName ? 'hidden' : ''}>  &nbsp; Enter a Store Name</span>
                                    </div>
                                    <p>&nbsp;</p>
                                    <div>
                                        <label>Address:  &nbsp;</label>
                                        <input type="text"
                                            id="storeaddress"
                                            name="storeaddress"
                                            style={FieldSize}
                                            onChange={this.onHandleAddress}
                                            value={this.state.addressval}>
                                        </input>
                                        <span id="storemsg" style={AllFieldsMsg} className={this.state.showAddress ? 'hidden' : ''}> &nbsp; Enter a Store Address</span>
                                    </div>
                                </div >
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-danger" onClick={handleClose}>Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
};

// Title
class StoreHead extends React.Component {
    render() {
        return (
            <div>
                <h2>All Stores </h2>
                <div><CreateBtn /></div>
            </div>
        )
    }
}


// Create
class CreateBtn extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            newstore: { Id: "0", StoreName: "", StoreAddress: "" }
        }
    }

    handleModal() {
        ReactDOM.render(
            <Modal show={true} store={this.state.newstore} />,
            document.getElementById("modal")
        )
    }

    render() {
        return (
            <div>
                <button className="btn btn-success m-2" onClick={() => this.handleModal("Create")} >
                    Create
                </button>
                <p></p>
            </div>
        );
    }
}

// Table
class TableReact extends React.Component {
    constructor(props) {
        super(props);
        this.state = { items: [] };
    }

    componentDidMount() {
        const { items } = this.state;
        fetch('/Store/GetStore')
            .then((responseText) => responseText.json())
            .then((response) => this.setState({ items: response }))
    }
    render() {
        const { items } = this.state;
        var rows = items.map(function (row) {
            return <tr key={row.Id}>
                <td style={Identity}>{row.Id}</td>
                <td>{row.StoreName}</td>
                <td>{row.StoreAddress}</td>
                <td style={Button}><EditBtn store={row} /></td>
                <td style={Button}><DeletBtn deletestore={row.Id} /></td>
            </tr>
        });
        return <table className="table table-bordered">
            <thead>
                <tr>
                    <th style={TableHeader}>Id</th>
                    <th style={TableHeader}>Name</th>
                    <th style={TableHeader}>Address</th>
                    <th colSpan={2} style={Buttons}>Action</th>
                </tr>
            </thead>
            <tbody>
                {rows}
            </tbody>
        </table>
    }
}

class EditBtn extends React.Component {
    constructor(props) {
        super(props);
        this.state = { show: true };
    }

    handleModal() {
        ReactDOM.render(
            <Modal show={true} store={this.props.store} />,
            document.getElementById("modal")
        );
    }

    render() {
        return (
            <div>
                <button className="btn btn-success m-2" onClick={() => this.handleModal("Edit")}>
                    Edit
                </button>
            </div>
        );
    }
}

class DeletBtn extends React.Component {
    constructor(props) {
        super(props);
    }

    handleDelete(deletestore) {
        if (confirm("Are you sure?")) {
            $.ajax({
                url: 'Store/Delete',
                data: { Id: deletestore },
                type: 'POST',
                datatype: 'json'
            })
                .success(function (result) {
                    alert(result.Message);
                    location.reload();
                })

                .error(function (xhr, status) {
                    alert("Unable to delete record. Contact the administrator.");
                    location.reload();
                })
        }
    }

    render() {
        return (
            <div>
                <button className={"btn btn-danger m-2"} onClick={() => this.handleDelete(this.props.deletestore)} >
                    Delete
                </button>
            </div>
        );
    }
}

// Functions
function handleClose() {
    ReactDOM.render(
        <Modal show={false} store=''></Modal>,
        document.getElementById('modal')
    )
}

// Render
ReactDOM.render(
    <StoreLayout />,
    document.getElementById("StoreLayout")
)
