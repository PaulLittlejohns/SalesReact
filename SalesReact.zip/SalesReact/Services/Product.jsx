﻿class ProductLayout extends React.Component {
    constructor(props) {
        super(props);
        this.state = { show: false }
    }
    render() {
        return (
            <div>
                <ProductHead />
                <TableReact />
            </div>
        );
    }

}

//Modal
class Modal extends React.Component {
    constructor(props) {
        super(props);
        var setprice = this.props.product.ProductPrice.toFixed(2)
        this.state = {
            idval: this.props.product.Id,
            nameval: this.props.product.ProductName,
            price: setprice,
            showName: false,
            showPrice: false,
            saveBtn: '',
            headingMsg: ''
        }
        this.onHandleName = this.onHandleName.bind(this);
        this.onHandlePrice = this.onHandlePrice.bind(this);
        this.handleSave = this.handleSave.bind(this);
    }

    componentDidMount() {
        if (this.props.product.Id === '0') {
            this.setupCreateLabels()
        } else {
            this.setupEditLabels()
        }
    }

    componentWillReceiveProps(prevProps, prevState) {
        if (typeof prevProps.product.Id != "undefined") {
            if (prevProps.product.Id === "0") {
                this.setupCreateLabels()
            } else {
                this.setupEditLabels()
            }
            this.state.nameval = prevProps.product.ProductName
            this.state.price = prevProps.product.ProductPrice.toFixed(2)
        }
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.product.Id != prevState.idval) {
            this.setState({ idval: this.props.product.Id, nameval: this.props.product.ProductName, price: this.props.product.ProductPrice.toFixed(2) })
            if (prevProps.product.Id == '0') {
                this.setupCreateLabels()
            } else if (typeof prevProps.product.Id != 'undefined') {
                this.setupEditLabels()
            }
        }
    }

    setupCreateLabels() {
        this.setState({ showName: false, showPrice: false, saveBtn: 'Create', headingMsg: 'Create Record' })
    };

    setupEditLabels() {
        this.setState({ showName: true, showPrice: true, saveBtn: 'Save', headingMsg: 'Edit Record' })
    };

    onHandleName(e) {
        this.setState({ nameval: e.target.value })
        if (e.target.value.length == 0) {
            this.setState({ showName: false })
        } else {
            this.setState({ showName: true })
        }
    }

    onHandlePrice(e) {
        this.setState({ price: e.target.value })
        var isvalid = false
        // check price
        if (isNaN(e.target.value * 100 / 100)) {
            isvalid = false
        } else if (e.target.value.indexOf(".") === -1) {
            isvalid = false
        } else if (e.target.value.substring(e.target.value.indexOf(".")).length !== 3) {
            isvalid = false
        } else if (e.target.value < 1.00)
            isvalid = false
        else {
            isvalid = true
        }
        this.setState({ showPrice: isvalid })
    }

    disableButton() {
        if (this.state.showName == false || this.state.showPrice == false) {
            return true
        } else {
            return false
        }
    }

    handleSave() {
        var id = this.state.idval;
        var name = this.state.nameval;
        var price = this.state.price;
        $.ajax({
            url: 'Product/Save',
            data: {
                Id: id,
                ProductName: name,
                ProductPrice: price
            },
            type: 'POST',
            datatype: 'json'
        })
            .success(function (result) {
                alert(result.Message);
                location.reload();
            })
            .error(function (xhr, status) {
                alert("Unable to save changes. Contact the administrator");
                location.reload();
            })
    }

    render() {
        const showHideClassName = this.props.show ? "modal display-block" : "modal display-none"
        return (
            <div className={showHideClassName}>
                <div className="modal-fade">
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-header">
                                <button type="button"
                                    className="close"
                                    onClick={handleClose}>&times;
                                 </button>
                                <h4 className="modal-title float-left">{this.state.headingMsg}</h4>
                            </div>
                            <div></div>
                            <div className="modal-body">
                                <div className="form-horizontal">
                                    <button type="button" className="btn btn-success" disabled={this.disableButton()} onClick={this.handleSave}>{this.state.saveBtn}</button>
                                    <div id="productid" name="productid" hidden="hidden">{this.state.idval}</div>
                                    <p>&nbsp;</p>
                                    <div>
                                        <h3 style={AllFieldsMsg}>All fields must have a value</h3>
                                    </div>
                                    <p>&nbsp;</p>
                                    <div>
                                        <label>Name: &nbsp;</label>
                                        <input type="text"
                                            id="productname"
                                            name="productrname"
                                            style={FieldSize}
                                            onChange={this.onHandleName}
                                            value={this.state.nameval}>
                                        </input>
                                        <span id="productmsg" style={AllFieldsMsg} className={this.state.showName ? 'hidden' : ''}>  &nbsp; Enter a Product Name</span>
                                    </div>
                                    <p>&nbsp;</p>
                                    <div>
                                        <label>Price:  &nbsp;</label>
                                        <input type="text"
                                            id="price"
                                            name="price"
                                            style={FieldSize}
                                            onChange={this.onHandlePrice}
                                            value={this.state.price}>
                                        </input>
                                        <span id="pricemsg" style={AllFieldsMsg} className={this.state.showPrice ? 'hidden' : ''}> &nbsp; Enter a Price</span>
                                    </div>
                                </div >
                                <span id="pricewarning" style={AllFieldsMsg}>Enter $ value (nn.nn) greater than $1.00</span>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-danger" onClick={handleClose}>Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

// Title
class ProductHead extends React.Component {
    render() {
        return (
            <div>
                <h2>All Products</h2>
                <div><CreateBtn /></div>
            </div>
        );
    }
}

// Create
class CreateBtn extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            newproduct: { Id: "0", ProductName: "", ProductPrice: 0 }
        }
    }

    handleModal() {
        ReactDOM.render(
            <Modal show={true} product={this.state.newproduct} />,
            document.getElementById("modal")
        )
    }

    render() {
        return (
            <div>
                <button className="btn btn-success m-2" onClick={() => this.handleModal("Create")}>
                    Create
                </button>
                <p></p>
            </div>
        );
    }
}

// Table
class TableReact extends React.Component {
    constructor(props) {
        super(props);
        this.state = { items: [] };
    }

    componentDidMount() {
        const { items } = this.state;
        fetch('/Product/GetProduct')
            .then((responseText) => responseText.json())
            .then((response) => this.setState({ items: response }))
    }
    render() {
        const { items } = this.state;
        var rows = items.map(function (row) {
            return <tr key={row.Id}>
                <td style={Identity}>{row.Id}</td>
                <td>{row.ProductName}</td>
                <td>{row.ProductPrice.toFixed(2)}</td>
                <td style={Button}><EditBtn product={row} /></td>
                <td style={Button}><DeleteBtn deleteprod={row.Id} /></td>
            </tr>
        });
        return <table className="table table-bordered">
            <thead>
                <tr>
                    <th style={TableHeader}>Id</th>
                    <th style={TableHeader}>Name</th>
                    <th style={TableHeader}>Price</th>
                    <th colSpan={2} style={Buttons}>Action</th>
                </tr>
            </thead>
            <tbody>
                {rows}
            </tbody>
        </table>
    }
}

class EditBtn extends React.Component {
    constructor(props) {
        super(props);
        this.state = { show: true };
    }

    handleModal() {
        ReactDOM.render(
            <Modal show={true} product={this.props.product} />,
            document.getElementById("modal")
        );
    }

    render() {
        return (
            <div>
                <button className="btn btn-success m-2" onClick={() => this.handleModal("Edit")}>
                    Edit
                </button>
                <p></p>
            </div>
        );
    }
}

class DeleteBtn extends React.Component {
    constructor(props) {
        super(props);
    }

    handleDelete(deleteprod) {
        if (confirm("Are you sure?")) {
            $.ajax({
                url: '/Product/Delete',
                data: { id: deleteprod },
                type: 'POST',
                datatype: 'json'
            })
                .success(function (result) {
                    alert(result.Message);
                    location.reload();
                })
                .error(function (xhr, status) {
                    alert("Unable to delete record. Contact the administrator.");
                    location.reload();
                })
        }

    }

    render() {
        return (
            <div>
                <button className={"btn btn-danger m-2"} onClick={() => this.handleDelete(this.props.deleteprod)}>
                    Delete
                </button>
                <p></p>
            </div>
        );
    }
}
// Functions
function handleClose() {
    ReactDOM.render(
        <Modal show={false} product="" />,
        document.getElementById("modal")
    )
}
// Render
ReactDOM.render(
    <ProductLayout />,
    document.getElementById("ProductLayout")
)