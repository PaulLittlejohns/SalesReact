﻿class SalesLayout extends React.Component {
    constructor(props) {
        super(props);
        this.state = { show: false }
    }

    render() {
        return (
            <div>
                <StoreHead />
                <TableReact />
            </div>
        );
    }
}

// Modal
class Modal extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            idval: this.props.sale.Id,
            details: this.props.sale,
            saveBtn: '',
            headingMsg: '',
            disableBtn: '',
            selectedprod: '',
            selectedcust: '',
            selectedstore: '',
            saledate: ''
        }
        this.handleSave = this.handleSave.bind(this);
        this.disableButton = this.disableButton.bind(this);
    }

    componentDidMount() {
        if (this.props.sale.Id === '0') {
            this.setupCreateLabels()
        } else {
            this.setupEditLabels()
        }
    }

    componentWillReceiveProps(prevProps, prevState) {
        if (typeof prevProps.sale.Id != "undefined") {
            if (prevProps.sale.Id === "0") {
                this.setupCreateLabels()
            } else {
                this.setupEditLabels()
            }
            this.setState({ details: this.props.sale })
            this.setState({ idval: this.props.sale.Id })
        }
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.sale.Id != prevState.idval) {
            this.setState({ details: this.props.sale })
            this.setState({ idval: this.props.sale.Id })
            if (prevProps.sale.Id == '0') {
                this.setupCreateLabels()
            } else if (typeof prevProps.sale.Id != 'undefined') {
                this.setupEditLabels()
            }
        } 
    }

    setupCreateLabels() {
        this.setState({ saveBtn: 'Create', headingMsg: 'Create Record', disableBtn: 'disabled'  })
    };

    setupEditLabels() {
        this.setState({ saveBtn: 'Save', headingMsg: 'Edit Record', disableBtn: '' })
    };
    
    disableButton = (prodid, custid, storeid, dateofsale) => {
            if (prodid === "0" || custid === "0" || storeid === "0" || dateofsale.length == "0") {
                this.setState({ disableBtn: 'disable' })
            } else {
                this.setState({ disableBtn: '' })
        }
        this.state.selectedprod = prodid
        this.state.selectedcust = custid
        this.state.selectedstore = storeid
        this.state.saledate = dateofsale
    }

    handleSave() {
        var id = this.state.idval;
        var product = this.state.selectedprod;
        var customer = this.state.selectedcust;
        var store = this.state.selectedstore;
        var saledate = this.state.saledate;
        $.ajax({
            url: 'TotalSales/Save',
            data: {
                Id: id,
                ProductId: product,
                CustomerId: customer,
                StoreId: store,
                DateOfSale: saledate
            },
            type: 'POST',
            datatype: 'json',
        })
            .success(function (result) {
                alert(result.Message);
                location.reload();
            })

            .error(function () {
                alert("Unable to save changes. Contact the administrator.");
                location.reload();
            })
    }

    render() {
        const showHideClassName = this.props.show ? "modal display-block" : "modal display-none"
        return (
            <div className={showHideClassName}>
                <div className="modal-fade">
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-header">
                                <button type="button"
                                    className="close"
                                    onClick={handleClose}
                                    >&times;
                                 </button>
                                <h4 className="modal-title float-left">{this.state.headingMsg}</h4>
                            </div>
                            <div></div>
                            <div className="modal-body">
                                <div className="form-horizontal">
                                    <button type="button" className="btn btn-success" onClick={this.handleSave} disabled={this.state.disableBtn}>{this.state.saveBtn}</button>
                                    <div id="salesid" name="saleid" hidden="hidden">{this.state.idval}</div>
                                    <p>&nbsp;</p>
                                    <div>
                                        <h3 style={AllFieldsMsg}>All fields must have a value</h3>
                                    </div>
                                    <p>&nbsp;</p>
                                    <div>
                                        <BindDropDowns details={this.state.details} callBackFromSel={this.disableButton} />
                                    </div>
                                </div >
                            </div>
                            <div className="modal-footer">
                                <div>
                                    <button className="btn btn-danger m-2" onClick={handleClose}>
                                        Close
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
};

// Title
class StoreHead extends React.Component {
    render() {
        return (
            <div>
                <h2>All Sales </h2>
                <div><CreateBtn /></div>
            </div>
        )
    }
}


// Create
class CreateBtn extends React.Component {
    constructor(props) {
        super(props);
        var date = getDate()
        this.state = {
            newsale: { Id: "0", ProductId: "0", CustomerId: "0", StoreId: "0", SaleDate: date, DateOfSale: new Date() }
        }
    }

    handleModal() {
        ReactDOM.render(
            <Modal show={true} sale={this.state.newsale} />,
            document.getElementById("modal")
        )
    }

    render() {
        return (
            <div>
                <button className="btn btn-success m-2" onClick={() => this.handleModal("Create")} >
                    Create
                </button>
                <p></p>
            </div>
        );
    }
}

// Table
class TableReact extends React.Component {
    constructor(props) {
        super(props);
        this.state = { items: [] };
    }

    componentDidMount() {
        const { items } = this.state;
        fetch('/TotalSales/GetSales')
            .then((responseText) => responseText.json())
            .then((response) => this.setState({ items: response }))
    }
    render() {
        const { items } = this.state;
        var rows = items.map(function (row) {
            return <tr key={row.Id}>
                <td style={Identity}>{row.Id}</td>
                <td>{row.ProductName}</td>
                <td>{row.CustomerName}</td>
                <td>{row.StoreName}</td>
                <td style={TableHidden}>{row.ProductId}</td>
                <td style={TableHidden}>{row.CustomerId}</td>
                <td style={TableHidden}>{row.StoreId}</td>
                <td style={TableHidden}>{row.SaleDate}</td>
                <td>{row.DateOfSale}</td>
                <td style={Button}><EditBtn sale={row} /></td>
                <td style={Button}><DeletBtn deletesale={row.Id} /></td>
            </tr>
        });
        return <table className="table table-bordered">
            <thead>
                <tr>
                    <th style={TableHeader}>Id</th>
                    <th style={TableHeader}>Product</th>
                    <th style={TableHeader}>Customer</th>
                    <th style={TableHeader}>Store</th>
                    <th style={TableHidden}>ProductId</th>
                    <th style={TableHidden}>CustomerId</th>
                    <th style={TableHidden}>StoreId</th>
                    <th style={TableHeader}>Sale Date</th>
                    <th style={TableHidden}>Date of Sale</th>
                    <th colSpan={2} style={Buttons}>Action</th>
                </tr>
            </thead>
            <tbody>
                {rows}
            </tbody>
        </table>
    }
}

class BindDropDowns extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            prodvalues: [],
            custvalues: [],
            storevalues: [],
            showProductMsg: false,
            showCustomerMsg: false,
            showStoreMsg: false,
            showDateMsg: true,
            pleasesel: false,
            identity: 'Whatever',
            productId: '',
            customerId: '',
            storeId: '',
            saledate: ''
        };
        const productId = this.props.details.ProductId
        const customerId = this.props.details.CustomerId
        const storeId = this.props.details.StoreId
        const saledate = this.props.details.SaleDate
        this.onHandleProd = this.onHandleProd.bind(this);
        this.onHandleCust = this.onHandleCust.bind(this);
        this.onHandleStore = this.onHandleStore.bind(this);
        this.handleDateSelector = this.handleDateSelector.bind(this);
    }

    componentDidMount(prevProps, prevState) {
        const { prodvalues, custvalues, storevalues } = this.state;
        fetch('/TotalSales/GetSelectLists')
            .then((responseText) => responseText.json())
            .then((response) => this.setState({
                prodvalues: response.products,
                custvalues: response.customers,
                storevalues: response.stores
            }).bind(this))  
    }

    componentWillReceiveProps(prevProps, prevState) {

    }

    componentDidUpdate(prevProps, prevState) {
        if (prevProps.details.Id != this.state.identity) {
            this.setState({ identity: prevProps.details.Id })
            this.setState({
                productId: this.props.details.ProductId,
                customerId: this.props.details.CustomerId,
                storeId: this.props.details.StoreId,
                saledate: this.props.details.SaleDate
            })
        }
    }

    onHandleSel(prodId, custId, storeId, saledate) {
        this.props.callBackFromSel(prodId, custId, storeId, saledate)
    }

    onHandleProd = (e) => {
        this.state.productId = e.target.value
        if (e.target.value === "0") {
            this.setState({ showProductMsg: false })
        } else {
            this.setState({ showProductMsg: true })
        }
        this.onHandleSel(this.state.productId, this.state.customerId, this.state.storeId, this.state.saledate)
    }
    onHandleCust = (e) => {
        this.state.customerId = e.target.value
        if (e.target.value === "0") {
            this.setState({ showCustomerMsg: false })
        } else {
            this.setState({ showCustomerMsg: true })
        }
        this.onHandleSel(this.state.productId, this.state.customerId, this.state.storeId, this.state.saledate)
    }

    onHandleStore = (e) => {
        this.state.storeId = e.target.value
        if (e.target.value === "0") {
            this.setState({ showStoreMsg: false })
        } else {
            this.setState({ showStoreMsg: true })
        }
        this.onHandleSel(this.state.productId, this.state.customerId, this.state.storeId, this.state.saledate)

    }

    handleDateSelector = (e) => {
        this.state.saledate = e.target.value
        if (e.target.value.length == "0") {
            this.setState({ showDateMsg: false })
        } else {
            this.setState({ showDateMsg: true })
        }
        this.onHandleSel(this.state.productId, this.state.customerId, this.state.storeId, this.state.saledate)
    }

    render() {
        var pleasesel = {
            "Disabled": "false",
            "Grouped": "null",
            "Selected": "false",
            "Text": "--- Please Select---",
            "Value": "0"
        }

        if (typeof this.state.prodvalues[0] != "undefined") {
            if (this.props.details.Id === "0") {
                if (this.state.productId === "0") {
                    this.state.showProductMsg = false
                }
                if (this.state.customerId === "0") {
                    this.state.showCustomerMsg = false
                }
                if (this.state.storeId === "0") {
                    this.state.showStoreMsg = false
                }
            } else {
                this.state.showProductMsg = true
                this.state.showCustomerMsg = true
                this.state.showStoreMsg = true
            }
            if (this.props.details.Id === "0" && !this.state.pleasesel) {
                this.state.prodvalues.unshift(pleasesel)
                this.state.custvalues.unshift(pleasesel)
                this.state.storevalues.unshift(pleasesel)
                this.state.pleasesel = true
            } else if (this.props.details.Id != "0" && this.state.pleasesel) {
                this.state.prodvalues.shift(pleasesel)
                this.state.custvalues.shift(pleasesel)
                this.state.storevalues.shift(pleasesel)
                this.state.pleasesel = false
            }
        }


        let optionProducts = this.state.prodvalues.map(p => (
            <option key={p.Value} value={p.Value}>{p.Text}</option>
        ));

        let optionCustomers = this.state.custvalues.map(c => (
            <option key={c.Value} value={c.Value}>{c.Text}</option>
        ));

        let optionStores = this.state.storevalues.map(s => (
            <option key={s.Value} value={s.Value}>{s.Text}</option>
        ));

        return (
            <div>
                <label>Product : &nbsp;</label>
                <select id='selprod' key={this.state.value} value={this.state.productId} onChange={this.onHandleProd}>
                    {optionProducts}
                </select>
                <span id="storemsg" style={AllFieldsMsg} className={this.state.showProductMsg ? 'hidden' : ''}>  &nbsp; Select a Product</span>
                <p></p>
                <label>Customers : &nbsp;</label>
                <select key={this.state.value} value={this.state.customerId} onChange={this.onHandleCust}>
                    {optionCustomers}
                </select>
                <span id="storemsg" style={AllFieldsMsg} className={this.state.showCustomerMsg ? 'hidden' : ''}>  &nbsp; Select a Customer</span>
                <p></p>
                <label>Stores : &nbsp;</label>
                <select key={this.state.value} value={this.state.storeId} onChange={this.onHandleStore}>
                    {optionStores}
                </select>
                <span id="storemsg" style={AllFieldsMsg} className={this.state.showStoreMsg ? 'hidden' : ''}>  &nbsp; Select a Store</span>
                <p></p>
                <label>Select a date : &nbsp; </label>
                <input type="date" onChange={this.handleDateSelector} value={this.state.saledate} />
                <span id="datemsg" style={AllFieldsMsg} className={this.state.showDateMsg ? 'hidden' : ''}> &nbsp; Select a Sale Date </span>
            </div>
        );
    }
}


class EditBtn extends React.Component {
    constructor(props) {
        super(props);
        this.state = { show: true };
    }
    handleModal() {
        ReactDOM.render(
            <Modal show={true} sale={this.props.sale} />,
            document.getElementById("modal")
        );
    }

    render() {
        return (
            <div>
                <button className="btn btn-success m-2" onClick={() => this.handleModal("Edit")}>
                    Edit
                </button>
            </div>
        );
    }
}

class DeletBtn extends React.Component {
    constructor(props) {
        super(props);
    }

    handleDelete() {
        if (confirm("Are you sure?")) {
            $.ajax({
                url: 'TotalSales/Delete',
                data: { Id: this.props.deletesale },
                type: 'POST',
                datatype: 'json'
            })
                .success(function (result) {
                    alert(result.Message);
                    location.reload();
                })

                .error(function (xhr, status) {
                    alert("Unable to delete record. Contact the administrator.");
                    location.reload();
                })
        }
    }

    render() {
        return (
            <div>
                <button className={"btn btn-danger m-2"} onClick={() => this.handleDelete(this.props.deletestore)} >
                    Delete
                </button>
            </div>
        );
    }
}
// Functions
function getDate() {
    var sysdate = new Date();
    var day = sysdate.getDate();
    var month = sysdate.getMonth() + 1;
    var year = sysdate.getFullYear();
    if (day < 10) {
        day = "0" + day
    }
    if (month < 10) {
        month = "0" + month
    }
    return year +'-'+ month + '-' + day
}

function handleClose() {
    ReactDOM.render(
        <Modal show={false} sale=''></Modal>,
        document.getElementById('modal')
    )
}
// Render
ReactDOM.render(
    <SalesLayout />,
    document.getElementById("SalesLayout")
)
