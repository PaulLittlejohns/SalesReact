﻿const Content = {
    width: "800px",
    margin: "auto"
};

const Header = {
    padding: "10px 20px",
    textAlign: "left",
    fontSize: "22px"
};

const TableHeader = {
    textAlign: "center",
    background: "white"
}

const  Identity = {
    textAlign: "center"
}

const TableHidden = {
    display: "none"
}

const TableButton = {
    width: "60px",
    padding: "5px",
    textAlign: "center",
    background: "white"
}

const Buttons = {
    width: "30px",
    textAlign: "center",
    background: "white"
}

const Button = {
    width: "30px",
    background: "white"
}

const AllFieldsMsg = {
    color: "red"
}

const FieldSize = {
    width: "400px"
}

const ModalFront = {
    index: "9999"
}
