﻿class CustomerLayout extends React.Component {
    constructor(props) {
        super(props);
        this.state = { show: false }
    }

    render() {
        return (
            <div>
                <CustHead />
                <TableReact />
            </div>
        );
    }
}

// Modal
class Modal extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            idval: this.props.customer.Id,
            nameval: this.props.customer.CustomerName,
            addressval: this.props.customer.CustomerAddress,
            showName: false,
            showAddress: false,
            saveBtn: '',
            headingMsg: ''
        }
        this.onHandleName = this.onHandleName.bind(this);
        this.onHandleAddress = this.onHandleAddress.bind(this);
        this.handleSave = this.handleSave.bind(this);
    }

    componentDidMount() {
        if (this.props.customer.Id === '0') {
            this.setupCreateLabels()
        } else {
            this.setupEditLabels()
        }
    }

    componentWillReceiveProps(prevProps, prevState) {
        if (typeof prevProps.customer.Id != "undefined") {
            if (prevProps.customer.Id === "0") {
                this.setupCreateLabels()
            } else {
                this.setupEditLabels()
            }
            this.state.nameval = prevProps.customer.CustomerName
            this.state.addressval = prevProps.customer.CustomerAddress 
        }
    }

    componentDidUpdate(prevProps, prevState) {
            if (prevProps.customer.Id != prevState.idval) {
                this.setState({ idval: this.props.customer.Id, nameval: this.props.customer.CustomerName, addressval: this.props.customer.CustomerAddress })
                if (prevProps.customer.Id == '0') {
                    this.setupCreateLabels()
                } else if (typeof prevProps.customer.Id != 'undefined') {
                    this.setupEditLabels()
                }
            }
        } 

    setupCreateLabels() {
        this.setState({ showName: false, showAddress: false, saveBtn: 'Create', headingMsg: 'Create Record' })
    };

    setupEditLabels() {
        this.setState({ showName: true, showAddress: true, saveBtn: 'Save', headingMsg: 'Edit Record' })
    };

    onHandleName(e) {
        this.setState({ nameval: e.target.value })
        if (e.target.value.length === 0) {
            this.setState({ showName: false })
        } else {
            this.setState({ showName: true })
        }
    }

    onHandleAddress(e) {
        this.setState({ addressval: e.target.value })
        if (e.target.value.length === 0) {
            this.setState({ showAddress: false })
        } else {
            this.setState({ showAddress: true })
        }
    }

    disableButton() {
        if (this.state.showName == false || this.state.showAddress == false) {
            return true
        } else {
            return false
        }
    }

    handleSave() {
        var id = this.state.idval;
        var name = this.state.nameval;
        var address = this.state.addressval;
        $.ajax({
            url: 'Customer/Save',
            data: {
                Id: id,
                CustomerName: name,
                CustomerAddress: address
            },
            type: 'POST',
            datatype: 'json'
        })
            .success(function (result) {
                alert(result.Message);
                location.reload();
            })
            .error(function () {
                alert("Unable to save changes. Contact the administrator.");
                location.reload;
            })
    }

    render() {
        const showHideClassName = this.props.show ? "modal display-block" : "modal display-none"
        return (
            <div className={showHideClassName}>
                <div className="modal-fade">
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-header">
                                <button type="button"
                                    className="close"
                                    onClick={handleClose}>&times;
                                 </button>
                                <h4 className="modal-title float-left">{this.state.headingMsg}</h4>
                            </div>
                            <div></div>
                            <div className="modal-body">
                                <div className="form-horizontal">
                                    <button type="button" className="btn btn-success" disabled={this.disableButton()} onClick={this.handleSave}>{this.state.saveBtn}</button>
                                    <div id="customerid" name="customerid" hidden="hidden">{this.state.idval}</div>
                                    <p>&nbsp;</p>
                                    <div>
                                        <h3 style={AllFieldsMsg}>All fields must have a value</h3>
                                    </div>
                                    <p>&nbsp;</p>
                                    <div>
                                        <label>Name: &nbsp;</label>
                                        <input type="text"
                                            id="customername"
                                            name="customername"
                                            style={FieldSize}
                                            onChange={this.onHandleName}
                                            value={this.state.nameval}>
                                        </input>
                                        <span id="customermsg" style={AllFieldsMsg} className={this.state.showName ? 'hidden' : ''}>  &nbsp; Enter a Customer Name</span>
                                    </div>
                                    <p>&nbsp;</p>
                                    <div>
                                        <label>Address:  &nbsp;</label>
                                        <input type="text"
                                            id="customeraddress"
                                            name="customeraddress"
                                            style={FieldSize}
                                            onChange={this.onHandleAddress}
                                            value={this.state.addressval}>
                                        </input>
                                        <span id="customermsg" style={AllFieldsMsg} className={this.state.showAddress ? 'hidden' : ''}> &nbsp; Enter a Customer Address</span>
                                    </div>
                                </div >
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-danger" onClick={handleClose}>Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
};

// Title
class CustHead extends React.Component {
    render() {
        return (
            <div>
                <h2>All Customers</h2>
                <div><CreateBtn /></div>
            </div>
        );
    }
}

// Create 
class CreateBtn extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            newcustomer: { Id: '0', CustomerName: '', CustomerAddress: '' }
        }
    }
    handleModal() {
        ReactDOM.render(
            <Modal show={true} customer={this.state.newcustomer} />,
            document.getElementById('modal')
        );
    }
    render() {
        return (
            <div>
                <button className="btn btn-success m-2" onClick={() => this.handleModal("Create")}>
                    Create
                </button>
                <p></p>
            </div>
        );
    }
}

// Edit
class EditBtn extends React.Component {
    constructor(props) {
        super(props);
        this.state = { show: true }
    }
    handleModal() {
        ReactDOM.render(
            <Modal show={true} customer={this.props.customer} />,
            document.getElementById('modal')
        );
    }

    render() {
        return (
            <div>
                <button className="btn btn-success m-2" onClick={() => this.handleModal("Edit")}>
                    Edit
                    </button>
                <p></p>
            </div>
        );
    }
}

// Delete
class DeleteBtn extends React.Component {
    constructor(props) {
        super(props);
    }
    handleDelete(deletecust) {
        if (confirm("Are you sure?")) {
            $.ajax({
                url: '/Customer/Delete',
                data: { id: deletecust },
                type: 'POST',
                datatype: 'json'
            })
                .success(function (result) {
                    alert(result.Message);
                    location.reload();
                })
                .error(function (xhr, status) {
                    alert("Unable to delete record. Contact the administrator.");
                    location.reload();
                })
        }
    }
    render() {
        return (
            <button className="btn btn-danger m-2" onClick={() => this.handleDelete(this.props.deletecust)}>
                Delete
            </button>
        );
    }
}

// Table
class TableReact extends React.Component {
    constructor(props) {
        super(props);
        this.state = { items: [] };
    }

    componentDidMount() {
        const { items } = this.state;
        fetch('/Customer/GetCustomer')
            .then((responseText) => responseText.json())
            .then((response) => this.setState({ items: response }))
    }

    render() {
        const { items } = this.state;
        var rows = items.map(function (row) {
            return <tr key={row.Id}>
                <td style={Identity}>{row.Id}</td>
                <td>{row.CustomerName}</td>
                <td>{row.CustomerAddress}</td>
                <td style={Button}><EditBtn customer={row} /></td>
                <td style={Button}><DeleteBtn deletecust={row.Id} /></td>
            </tr>
        });
        return <table className="table table-bordered">
            <thead>
                <tr>
                    <th style={TableHeader}>Id</th>
                    <th style={TableHeader}>Name</th>
                    <th style={TableHeader}>Address</th>
                    <th colSpan={2} style={Buttons}>Action</th>
                </tr>
            </thead>
            <tbody>
                {rows}
            </tbody>
        </table>
    }
};

// Functions
function handleClose() {
    ReactDOM.render(
        <Modal show={false} customer=''></Modal>,
        document.getElementById('modal')
    )
}

// Render
ReactDOM.render(
    <CustomerLayout />,
    document.getElementById("CustomerLayout")
)
