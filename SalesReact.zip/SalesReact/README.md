react-typescript-definitions
============================

React.d.ts, file with ambient type declarations for working with Facebook React.

With typings for React 0.10.0 and TS 1.0, but it’s kinda incomplete, so **pull requests are welcome**.

Based on TodoMVC sample by @fdecampredon, improved by @wizzard0, MIT licensed.

Include the file like this:

    /// <reference path="../vendor/react-typescript-definitions/react.d.ts" />

