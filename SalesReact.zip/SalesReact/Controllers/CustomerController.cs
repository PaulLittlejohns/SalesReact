﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using SalesReact.Models;

namespace SalesReact.Controllers
{
    public class CustomerController : Controller
    {
        Sales4Entities db = new Sales4Entities(); 
        // GET: Customer
        public ActionResult Index()
        {
            return View();
        }

        [OutputCache(Location = OutputCacheLocation.None)]
        public ActionResult GetCustomer()
        {
            var customerlist = db.Customers.Select(x => new CustomerViewModel
            {
                Id = x.Id,
                CustomerName = x.Name,
                CustomerAddress = x.Address
            }).ToList();

            return Json(customerlist, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Save(CustomerViewModel model)
        {
            int id = model.Id;
            string name = model.CustomerName;
            string address = model.CustomerAddress;
            string msg = " ";
            
            if (id == 0)
            { // new record
                try
                {
                    var Customer = new Customer() {
                        Name = name,
                        Address = address
                    };
                    db.Customers.Add(Customer);
                    db.SaveChanges();
                    msg = "New record created.";
                } catch (Exception) {
                    msg = "Unable to create record. Contact the administrator.";
                }
            } else
            { // edited record
                var customer = db.Customers.Find(id);
                if (customer == null)
                {
                    return HttpNotFound();
                }
                try
                {
                    customer.Id = id;
                    customer.Name = name;
                    customer.Address = address;
                    db.SaveChanges();
                    msg = String.Format("Changes to record {0} have been saved.", id);
                } catch(Exception)
                {
                    msg = "Unable to save changes. Contact the administrator.";
                }
            }
            var result = new { Message = msg };
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int id)
        {
            var customer = db.Customers.Find(id);
            string message = "";
            if (customer == null)
            {
                return HttpNotFound();
            }
            if (customer.Sales.Any())
            {
                message = "Unable to delete record. Check this Customer is not used by a Sale record.";
            }
            else
            { 
                try
                {
                    db.Customers.Remove(customer);
                    db.SaveChanges();
                    message = string.Format("Record {0} deleted", id);
                } catch (Exception)
                {
                    message = "Unable to delete record. contact the administrator.";
                }
            }

            var result = new { Message = message };
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}