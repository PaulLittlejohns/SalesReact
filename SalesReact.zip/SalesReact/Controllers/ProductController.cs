﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using SalesReact.Models;

namespace SalesReact.Controllers
{
    public class ProductController : Controller
    {
        Sales4Entities db = new Sales4Entities();
        // GET: Product
        public ActionResult Index()
        {
            return View();
        }

        [OutputCache(Location=OutputCacheLocation.None)]
        public ActionResult Getproduct()
        {
            var ProductList = db.Products.Select(x => new ProductViewModel
            {
                Id = x.Id,
                ProductName = x.Name,
                ProductPrice = x.Price
            }).ToList();                
            return Json(ProductList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Save(ProductViewModel model)
        {
            int id = model.Id;
            string name = model.ProductName;
            decimal? price = model.ProductPrice;
            string msg = "";
            if (id == 0)
            { // new record
                try
                {
                    var Product = new Product
                    {
                        Id = id,
                        Name = name,
                        Price = price
                    };
                    db.Products.Add(Product);
                    db.SaveChanges();
                    msg = "New record created.";
                } catch(Exception)
                {
                    msg = "Unable to create record. Contact the administrator";
                }
            } else
            { // edit record
                var product = db.Products.Find(id);
                if (product == null)
                {
                    return HttpNotFound();
                } else
                { try
                    {
                        product.Id = id;
                        product.Name = name;
                        product.Price = price;
                        db.SaveChanges();
                        msg = String.Format("Changes to record {0} have been saved.", id);
                    } catch (Exception)
                    {
                        msg = "Unable to save changes. Cointact the administrator.";
                    }
                }
            }
            var Result = new {Message = msg};
            return Json(Result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int id)
        {
            var msg = "";
            var product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            } else
            {
                if (product.Sales.Any())
                {
                    msg = "Unable to delete record. Check this Product is not used by a Sales record.";
                } else
                {
                    try
                    {
                        db.Products.Remove(product);
                        db.SaveChanges();
                        msg = string.Format("Record {0} has been deleted.", id);
                    }
                    catch (Exception)
                    {
                        msg = "Unable to delete record. Contact the administrator.";
                    }
                } 
            }
            var Result = new { Message = msg };
            return Json(Result, JsonRequestBehavior.AllowGet);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}