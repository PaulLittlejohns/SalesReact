﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using SalesReact.Models;

namespace SalesReact.Controllers
{
    public class StoreController : Controller
    {
        Sales4Entities db = new Sales4Entities();

        // GET: Store
        public ActionResult Index()
        {
            return View();
        }

        [OutputCache(Location = OutputCacheLocation.None)]
        public ActionResult GetStore()
        {
            var StoreList = db.Stores.Select(x => new StoreViewModel
            {
                Id = x.Id,
                StoreName = x.Name,
                StoreAddress = x.Address
            }).ToList();

            return Json(StoreList, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult Save (StoreViewModel model)
        {
            int id = model.Id;
            string name = model.StoreName;
            string address = model.StoreAddress;
            var msg = "";
            if (id == 0)
            { // new record
                try
                {
                    var store = new Store()
                    {
                        Id = model.Id,
                        Name = model.StoreName,
                        Address = model.StoreAddress
                    };
                    db.Stores.Add(store);
                    db.SaveChanges();
                    msg = "New record created.";
                } catch (Exception)
                {
                    msg = "Unable to save record. Contact the administrator.";
                }

            } else
            { // edit record
                var store = db.Stores.Find(id);
                if (store == null)
                {
                    return HttpNotFound();
                } else
                {   try
                    {
                        store.Id = id;
                        store.Name = name;
                        store.Address = address;
                        db.SaveChanges();
                        msg = string.Format("Changes to record {0} have been saved.", id);
                    } catch (Exception)
                    {
                        msg = "Unable to save changes. Contact the administrator.";
                    }
                }
            }
            var result = new { Message = msg };
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int id)
        {
            var store = db.Stores.Find(id);
            var msg = "";

            if (store == null)
            {
                return HttpNotFound();
            }

            if (store.Sales.Any())
            {
                msg = "Unable to delete record. Check this Store is not used by a Sale record.";
            } else {
                try
                {
                    db.Stores.Remove(store);
                    db.SaveChanges();
                    msg = string.Format("Record {0} has been deleted. ", id);
                } catch(Exception)
                {
                    msg = "Unable to delete record. Contact the administrator.";
                }
            }
            var Result = new { Message = msg};
            return Json(Result, JsonRequestBehavior.AllowGet);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}