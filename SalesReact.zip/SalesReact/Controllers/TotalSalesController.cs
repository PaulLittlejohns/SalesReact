﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Services.Description;
using System.Web.UI;
using SalesReact.Models;

namespace SalesReact.Controllers
{
    public class TotalSalesController : Controller
    {
        Sales4Entities db = new Sales4Entities();
        // GET: TotalSales
        public ActionResult Index()
        {
            return View();
        }

        [OutputCache(Location = OutputCacheLocation.None)]
        public ActionResult GetSales()
        {
            var saleslist = db.TotalSales.Select(x => new TotalSalesViewModel {
                Id = x.Id,
                ProductName = x.ProductName,
                ProductId = x.ProductId ?? 0,
                CustomerName = x.CustomerName,
                CustomerId = x.CustomerId ?? 0,
                StoreName = x.StoreName,
                StoreId = x.StoreId ?? 0,
                SaleDate = x.SaleDate ?? System.DateTime.Now
            }).ToList().Select(y => new
            {
                y.Id,
                y.ProductName,
                y.CustomerName,
                y.StoreName,
                y.ProductId,
                y.CustomerId,
                y.StoreId,
                SaleDate = String.Format("{0:yyyy-MM-dd}", y.SaleDate),
                DateOfSale = String.Format("{0:dd/MM/yyyy}", y.SaleDate)
            });
            return Json(saleslist, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetSelectLists()
        {
            var productlist = db.Products.Select(x => new ProductViewModel
            {
                Id = x.Id,
                ProductName = x.Name
            }).ToList();
            var customerlist = db.Customers.Select(x => new CustomerViewModel
            {
                Id = x.Id,
                CustomerName = x.Name
            }).ToList();        

            var storelist = db.Stores.Select(x => new StoreViewModel
            {
                Id = x.Id,
                StoreName = x.Name
            });
            SelectList products = new SelectList(productlist, "Id", "ProductName");
            SelectList customers = new SelectList(customerlist, "Id", "CustomerName");
            SelectList stores = new SelectList(storelist, "Id", "StoreName");
            var result = new { products, customers, stores };
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public ActionResult Save(TotalSalesViewModel model)
        {
            int id = model.Id;
            int prod = model.ProductId;
            int cust = model.CustomerId;
            int store = model.StoreId;
            DateTime saledate = Convert.ToDateTime(model.DateOfSale);
            var msg = "";

            if (id == 0)
            { // new record
              try
                {
                    var Sale = new Sale()
                    {
                        Id = id,
                        ProductId = prod,
                        CustomerId = cust,
                        Storeid = store,
                        Datesold = saledate
                    };
                    db.Sales.Add(Sale);
                    db.SaveChanges();
                    msg = "New record created.";
                } catch (Exception){
                    msg = "Unable to save new record. Contact the administrator.";
                }
            } else
            { //existing record
                var sale = db.Sales.Find(id);
                if (sale == null)
                {
                    return HttpNotFound();
                } else
                {
                    try
                    {
                        sale.Id = id;
                        sale.ProductId = prod;
                        sale.CustomerId = cust;
                        sale.Storeid = store;
                        sale.Datesold = saledate;
                        db.SaveChanges();
                        msg = string.Format("Changes to record {0} have been saved.", id);
                    } catch (Exception)
                    {
                        msg = "Unable to save changes. Contact the administrator.";
                    }
                }
            }
            var result = new { Message = msg };
            return Json(result, JsonRequestBehavior.AllowGet);
        } 
        public ActionResult Delete(int id)
        {
            var sale = db.Sales.Find(id);
            var msg = "";
            if (sale == null)
            {
                return HttpNotFound();
            }  
            try
            {
                db.Sales.Remove(sale);
                db.SaveChanges();
                msg = string.Format("Record {0} has been deleted.", id);
            } catch (Exception)
            {
                msg = "Unable to delete record. Contact the administrator.";
            }
            var result = new { Message = msg };
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}